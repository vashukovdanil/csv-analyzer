import sys
import pandas as pd
from PyQt5.QtWidgets import QApplication, QDialogButtonBox, QDialog, QListWidget, QSpinBox, QMainWindow, QFileDialog, QWidget, QTableWidget, QLabel, QProgressBar, QTableWidgetItem, QSlider, QLabel, QHeaderView, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QComboBox
from PyQt5.QtCore import Qt
from PyQt5 import QtGui
import matplotlib.pyplot as plt
from datetime import datetime
import os

# Окно ошибки или уведомления


class errorWindow(QWidget):
    def __init__(self, text):
        super().__init__()
        self.setUI(text)

    def setUI(self, text):
        label = QLabel(text)
        label.setAlignment(Qt.AlignCenter)
        okButton = QPushButton("OK")

        mainL = QVBoxLayout()
        mainL.addWidget(label)
        mainL.addWidget(okButton)

        self.setLayout(mainL)
        self.setWindowTitle("Уведомление")
        self.resize(350, 100)
        self.show()

        okButton.clicked.connect(self.close)

# Окно статистики


class Statistics(QWidget):

    def __init__(self, df):
        super().__init__()
        self._data = df.describe()
        self.setUI()

    def setUI(self):
        self.table = QTableWidget()

        self.mainLayout = QVBoxLayout(self)
        self.mainLayout.addWidget(self.table)
        self.resize(1200, 500)
        self.setWindowTitle('Статистика')
        self.show()

        self.fillTable()

    def fillTable(self):
        df = self._data

        self.table.setColumnCount(len(list(df.columns)))
        self.table.setRowCount(len(df))

        self.table.setHorizontalHeaderLabels(list(df.columns))
        self.table.setVerticalHeaderLabels(list(df.index))
        self.table.verticalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        for i in range(len(df)):
            for j in range(len(list(df.columns))):
                self.table.setItem(i, j, QTableWidgetItem(str(df.iloc[i, j])))

# Графики


class Graph(QWidget):
    def __init__(self, df):
        super().__init__()
        self.counter = 0
        df = df.reset_index()
        df = df.iloc[:, 1:]
        self.selected = []
        self._data = df.loc[:99]
        self.setUI()

    def setUI(self):

        self.openGraphButton = QPushButton("Построить график")

        # выбор гарфика
        self.graphType = QComboBox()
        self.graphType.addItems(['Bar', 'Box', 'Pie', 'Plot'])

        # выбор данных
        self.columnLabel = QLabel("Столбец:")
        self.columnLabel.setAlignment(Qt.AlignRight)
        self.dataColumn = QComboBox()
        itms = [
            column for column in self._data.columns if column not in self._data._get_numeric_data()]
        self.dataColumn.addItems(itms)
        self.dataRangeLabel = QLabel("Первые:")
        self.dataRangeLabel.setAlignment(Qt.AlignRight)
        self.dataRange = QSpinBox()
        self.dataRange.setMinimum(2)

        if len(self._data.index) < 100:
            self.dataRange.setMaximum(int(len(self._data.index)))
        else:
            self.dataRange.setMaximum(100)

        self.columnSettings = QHBoxLayout()
        self.columnSettings.addWidget(self.columnLabel)
        self.columnSettings.addWidget(self.dataColumn)
        self.columnSettings.setAlignment(Qt.AlignLeft)

        self.rangeSettings = QHBoxLayout()
        self.rangeSettings.addWidget(self.dataRangeLabel)
        self.rangeSettings.addWidget(self.dataRange)

        self.dataSettings = QHBoxLayout()
        self.dataSettings.addLayout(self.columnSettings)
        self.dataSettings.addLayout(self.rangeSettings)

        # ВЫБОР СТОЛБЦОВ
        self.dataLabel = QLabel("Данные:")
        self.nonSelectedCols = QListWidget()
        self.nonSelectedCols.addItems(list(self._data._get_numeric_data()))
        self.selectedCols = QListWidget()
        self.buttonAdd = QPushButton(">")
        self.buttonAdd.setFixedWidth(30)
        self.buttonDel = QPushButton("<")
        self.buttonDel.setFixedWidth(30)
        self.buttonLayer = QVBoxLayout()
        self.buttonLayer.addWidget(self.buttonAdd)
        self.buttonLayer.addWidget(self.buttonDel)

        self.columnLayer = QHBoxLayout()
        self.columnLayer.addWidget(self.nonSelectedCols)
        self.columnLayer.addLayout(self.buttonLayer)
        self.columnLayer.addWidget(self.selectedCols)

        # ОСНОВНОЙ СЛОЙ
        self.mainLayout = QVBoxLayout()
        self.mainLayout.addWidget(self.graphType)
        self.mainLayout.addLayout(self.dataSettings)
        self.mainLayout.addWidget(self.dataLabel)
        self.mainLayout.addLayout(self.columnLayer)
        self.mainLayout.addWidget(self.openGraphButton)

        self.setLayout(self.mainLayout)
        self.setWindowTitle("Параметры графика")
        self.show()

        self.buttonAdd.clicked.connect(self.add)
        self.buttonDel.clicked.connect(self.delete)
        self.openGraphButton.clicked.connect(self.openGraph)

    def add(self):
        try:
            self.selectedCols.addItem(
                self.nonSelectedCols.currentItem().text())
            self.selected.append(self.nonSelectedCols.currentItem().text())
            self.nonSelectedCols.takeItem(
                self.nonSelectedCols.currentIndex().row())
        except:
            self.error = errorWindow(
                "Необходимо выбрать данные для перемещения")
            self.error.show()

    def delete(self):
        try:
            self.nonSelectedCols.addItem(
                self.selectedCols.currentItem().text())
            self.selected.remove(self.selectedCols.currentItem().text())
            self.selectedCols.takeItem(self.selectedCols.currentIndex().row())
        except:
            self.error = errorWindow(
                "Необходимо выбрать данные для перемещения")
            self.error.show()

    def openGraph(self):
        if self.selected != []:
            self.drawGraph(column=self.dataColumn.currentText(), columnList=self.selected,
                           graphType=self.graphType.currentText(), top=self.dataRange.value())

    def drawGraph(self, column, columnList, graphType, top):
        plt.close()
        grouped_df = self._data[:top].groupby([str(column)])
        grouped_df = grouped_df.sum()
        grouped_df = grouped_df.reset_index()

        if graphType == "Bar":
            grouped_df.plot.bar(x=str(column), y=columnList)
        elif graphType == "Plot":
            grouped_df.plot(x=str(column), y=columnList)
        elif graphType == "Box":
            grouped_df.plot.box(x=str(column), y=columnList)
        else:
            grouped_df[columnList].plot.pie(
                subplots=True, labels=grouped_df[column])
        plt.show()

#   ОСНОВНОЙ КЛАСС


class Reader(QWidget):
    def __init__(self, df):
        super().__init__()
        self.dataFrame = df

        now = datetime.now()
        self.month = now.strftime("%m")
        self.day = now.strftime("%d")
        self.time = now.strftime("%H_%M_%S")

        try:
            if self.dataFrame.iloc[1, 0] == (self.dataFrame.iloc[0, 0] + 1):
                self.dataFrame = self.dataFrame.iloc[:, 1:]
        except:
            self.dataFrame = self.dataFrame

        self.dataSet = None
        self.counter = 0
        self.temp = None
        self.operatorStatus = None
        self.setUI()

    def setUI(self):

        # Кнопки инструментов
        self.exportToExcel = QPushButton()
        self.exportToCSV = QPushButton()
        self.exportToExcel.setIcon(QtGui.QIcon('icons/excel.png'))
        self.exportToCSV.setIcon(QtGui.QIcon('icons/csv.png'))
        self.exportToExcel.setFixedSize(30, 30)
        self.exportToCSV.setFixedSize(30, 30)

        self.toolsLayout = QHBoxLayout()
        self.toolsLayout.addWidget(self.exportToExcel)
        self.toolsLayout.addWidget(self.exportToCSV)
        self.toolsLayout.setAlignment(Qt.AlignLeft)

        # элементы
        self.table = QTableWidget()
        self.searchLine = QLineEdit()
        self.progressBar = QProgressBar()
        self.progressBar.hide()

        # быстрые статистики
        self.countLabel = QLabel()
        self.countLabel.hide()
        self.unique = QLabel()
        self.unique.hide()
        self.avg = QLabel()
        self.avg.hide()

        # быстрые статистики (слой)
        self.stat = QHBoxLayout()
        self.stat.setAlignment(Qt.AlignRight)
        self.stat.addWidget(self.countLabel)
        self.stat.addWidget(self.unique)
        self.stat.addWidget(self.avg)

        # кнопка поиска
        self.buttonSearch = QPushButton()
        self.buttonSearch.setIcon(QtGui.QIcon('icons/loupe.png'))

        # кнопка сброса
        self.buttonRefresh = QPushButton()
        self.buttonRefresh.setIcon(QtGui.QIcon('icons/clear.png'))

        # кнопка графиков
        self.buttonGraph = QPushButton()
        self.buttonGraph.setIcon(QtGui.QIcon('icons/chart.png'))

        # кнопка статистики
        self.buttonStatistic = QPushButton()
        self.buttonStatistic.setIcon(QtGui.QIcon('icons/sum.png'))

        self.comboSearch = QComboBox()
        self.comboSearch.addItems(list(self.dataFrame))

        self.comboOperators = QComboBox()
        self.comboOperators.addItems(['=', '<=', '>='])
        self.comboOperators.hide()

        # поиск
        self.searchLayout = QHBoxLayout()
        self.searchLayout.addWidget(self.searchLine)
        self.searchLayout.addWidget(self.comboOperators)
        self.searchLayout.addWidget(self.comboSearch)
        self.searchLayout.addWidget(self.buttonSearch)
        self.searchLayout.addWidget(self.buttonRefresh)
        self.searchLayout.addWidget(self.buttonGraph)
        self.searchLayout.addWidget(self.buttonStatistic)

        # основной слой
        self.mainLayout = QVBoxLayout(self)
        self.mainLayout.addLayout(self.toolsLayout)
        self.mainLayout.addLayout(self.searchLayout)
        self.mainLayout.addWidget(self.table)
        self.mainLayout.addWidget(self.progressBar)
        self.mainLayout.addLayout(self.stat)

        self.setLayout(self.mainLayout)

        self.resize(1200, 800)
        self.setWindowTitle('Таблица')
        self.show()

        self.fillTable()

        # логика кнопок
        self.buttonSearch.clicked.connect(self.search)
        self.buttonRefresh.clicked.connect(self.refresh)
        self.buttonStatistic.clicked.connect(self.openStatistics)
        self.buttonGraph.clicked.connect(self.graphOpen)
        self.exportToExcel.clicked.connect(self.exportExcel)
        self.exportToCSV.clicked.connect(self.exportCSV)

        self.table.itemSelectionChanged.connect(self.selectionChanged)

        # при изменении комбо боксов
        self.comboSearch.activated.connect(self.onChangeColumn)
        self.comboOperators.activated.connect(self.onChangeOperator)

        self.table.horizontalHeader().sectionClicked.connect(self.onHeaderClicked)

    def exportExcel(self):
        if not os.path.exists("export/"):
            os.makedirs("export/")
        self.dataSet.to_excel(
            f"export/{self.day}_{self.month}_{self.time}.xlsx", index=False)

        self.error = errorWindow(
            "Файл успешно экспортирован")
        self.error.show()

    def exportCSV(self):
        if not os.path.exists("export/"):
            os.makedirs("export/")
        self.dataSet.to_csv(
            f"export/{self.day}_{self.month}_{self.time}.csv", index=False)
        self.error = errorWindow(
            "Файл успешно экспортирован")
        self.error.show()

    def selectionChanged(self):
        temp = self.dataSet.iloc[:, self.table.currentColumn()]
        temp = temp.describe()
        try:
            self.avg.hide()
            self.unique.setText("Уникальных значений: " +
                                str(temp.loc["unique"]))
        except:
            self.avg.show()
            self.avg.setText("AVG: " + str(round(float(temp.loc["mean"]), 3)))
            self.unique.setText("Значений: " + str(int(temp.loc["count"])))

        self.unique.show()

    def onHeaderClicked(self, logicalIndex):
        col = list(self.dataFrame.columns)
        self.fillTable(qwery=self.searchLine.text(), column=self.comboSearch.currentText(
        ), operator=self.operatorStatus, orderby=col[logicalIndex])

    def onChangeColumn(self):
        numeric = self.dataFrame._get_numeric_data()
        if self.comboSearch.currentText() in numeric.columns:
            self.comboOperators.show()
            self.operatorStatus = self.comboOperators.currentText()
        else:
            self.comboOperators.hide()
            self.buttonGraph.show()
            self.operatorStatus = None

    def onChangeOperator(self):
        self.operatorStatus = self.comboOperators.currentText()

    def graphOpen(self):
        self.graph = Graph(df=self.dataSet)
        self.graph.show()

    def search(self):
        if list(self.searchLine.text()):
            self.fillTable(qwery=self.searchLine.text(
            ), column=self.comboSearch.currentText(), operator=self.operatorStatus)

    def refresh(self):
        self.searchLine.setText("")
        self.fillTable()

    def openStatistics(self):
        self.statistic = Statistics(self.dataSet)
        self.statistic.show()

    def getDataSet(self, df, qwery=None, column=None, operator=None):
        # поиск
        if qwery != None:
            if operator == "=":
                df = df[df[column] == float(qwery)]
            elif operator == "<=":
                df = df[df[column] <= float(qwery)]
            elif operator == ">=":
                df = df[df[column] >= float(qwery)]
            else:
                df = df[df[column].str.contains(qwery, na=False)]
        return df

    def fillTable(self, qwery=None, column=None, operator=None, orderby=None):

        df = self.getDataSet(df=self.dataFrame, qwery=qwery,
                             column=column, operator=operator)

        self.progressBar.setRange(0, len(df))
        self.progressBar.show()

        self.countLabel.hide()
        self.unique.hide()
        self.avg.hide()

        self.countLabel.setText("Строк: " + str(len(df)))

        self.table.setColumnCount(len(list(df.columns)))
        self.table.setRowCount(len(df))
        self.table.verticalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        self.table.setHorizontalHeaderLabels(list(df.columns))

        if orderby != None:
            if self.temp == orderby:
                if self.counter == 0:
                    df = df.sort_values(orderby)
                    self.counter = 1
                else:
                    df = df.sort_values(orderby, ascending=False)
                    self.counter = 0
            else:
                df = df.sort_values(orderby)
                self.counter = 1

            self.temp = orderby

        for i in range(len(df)):
            self.progressBar.setValue(i)
            for j in range(len(list(df.columns))):
                self.table.setItem(i, j, QTableWidgetItem(str(df.iloc[i, j])))

        self.progressBar.hide()
        self.countLabel.show()
        self.dataSet = pd.DataFrame(df)

    def closeEvent(self, event):
        self.hub = Hub()
        self.hub.show()
        self.close()


class Hub(QWidget):
    def __init__(self):
        super().__init__()
        self.getUnique()
        self.setUI()

    def setUI(self):

        # открыть файл
        self.openFileButton = QPushButton("...")
        self.openFileButton.setMaximumWidth(50)
        self.sepLabel = QLabel("Разделитель")
        self.sepLabel.setAlignment(Qt.AlignRight)
        self.separator = QLineEdit(",")
        self.separator.setMaximumWidth(100)
        self.openFileLayout = QHBoxLayout()
        self.openFileLayout.addWidget(self.sepLabel)
        self.openFileLayout.addWidget(self.separator)
        self.openFileLayout.addWidget(self.openFileButton)

        # таблица с прошлыми файлами
        self.tableFiles = QListWidget()
        self.tableFiles.addItems(self.getTempFiles())

        # открыть существующий файл
        self.openCurrent = QPushButton("Открыть")
        self.openCurrent.hide()
        self.openCurrentLayout = QHBoxLayout()
        self.openCurrentLayout.addWidget(self.openCurrent)

        # ОСНОВНОЙ СЛОЙ
        self.hubLayout = QVBoxLayout()
        self.hubLayout.addLayout(self.openFileLayout)
        self.hubLayout.addWidget(self.tableFiles)
        self.hubLayout.addLayout(self.openCurrentLayout)

        self.setLayout(self.hubLayout)
        self.setWindowTitle('Главное окно')
        self.resize(600, 700)
        self.show()

        # логика
        self.openFileButton.clicked.connect(self.openFile)
        self.openCurrent.clicked.connect(self.openCurrentFile)
        self.tableFiles.currentRowChanged.connect(self.selectedCahnged)

    def getTempFiles(self):
        try:
            with open("temp.txt", 'r') as f:
                l = [str(el)[:-1] for el in f.readlines()]
        except:
            l = []
        return l

    def selectedCahnged(self):
        self.openCurrent.show()

    def writeTempFiles(self, data=[]):
        with open("temp.txt", "a") as f:
            f.writelines(data[0] + '\n')
            self.tableFiles.addItem(data[0])

    def openFile(self):
        fname = QFileDialog.getOpenFileName(
            self, "Открыть файл", "", ".csv(*.csv)")[0]
        if fname != "":
            self.writeTempFiles([fname])
            self.openTable(fname)

    def openCurrentFile(self):
        try:
            self.openTable(self.tableFiles.currentItem().text())
        except:
            self.tableFiles.takeItem(self.tableFiles.currentIndex().row())
            lfiles = self.getTempFiles()
            lfiles.pop(self.tableFiles.currentIndex().row())

            with open("temp.txt", "w") as f:
                for el in lfiles:
                    f.writelines(el + "\n")

            self.error = errorWindow(
                "Файла не существует")
            self.error.show()

    def openTable(self, path):
        sep = self.separator.text()
        df = pd.read_csv(path, sep)
        self.reader = Reader(df)
        self.reader.show()
        self.close()

    def getUnique(self):
        try:
            with open("temp.txt", "r") as f:
                l = [str(el)[:-1] for el in f.readlines()]

            unique = []
            for el in l:
                if el not in unique:
                    unique.append(el)

            with open('temp.txt', "w") as f:
                f.writelines([str(el) + "\n" for el in unique])
        except:
            with open('temp.txt', "w") as f:
                f.write('')


if __name__ == "__main__":
    app = QApplication(sys.argv)

    hub = Hub()
    hub.show()

    sys.exit(app.exec_())
